#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"

static void syscall_handler (struct intr_frame *);

void get_argument(void *esp, int *arg, int count);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  // printf ("system call!\n");

	check_address({const void *} f->esp);

  switch(*(int *) f->esp){
	case SYS_HALT: 
		halt();
		break;                  /* Halt the operating system. */
    case SYS_EXIT:                   /* Terminate this process. */
	get_argument(f, &arg[0], 1);
	eixt(arg[0]);
	break;
    case SYS_EXEC:                   /* Start another process. */
	break;
    case SYS_WAIT:                   /* Wait for a child process to die. */
	break;
    case SYS_CREATE:                 /* Create a file. */
	break;
    case SYS_REMOVE:                 /* Delete a file. */
	break;
    case SYS_OPEN:                   /* Open a file. */
	break;
    case SYS_FILESIZE:               /* Obtain a file's size. */
	break;
    case SYS_READ:                   /* Read from a file. */
	break;
    case SYS_WRITE:                  /* Write to a file. */
	break;
    case SYS_SEEK:                   /* Change position in a file. */
	break;
    case SYS_TELL:                   /* Report current position in a file. */
	break;
    case SYS_CLOSE:                  /* Close a file. */
	break;
	}


  // thread_exit ();
}

void halt(void){
	power_off();
}

void exit(int status){
	struct thread *current = thread_current();
	current->exit_status = status;

	printf("%s: exit(%d)\n", thread_name(), status);
	thread_exit();
}

void check_address(void *addr){
	if(!is_user_vaddr(addr) || addr == NULL || addr < (void *) 0x0804800){
		exit(-1);
	}
}

void get_argument(void *esp, int *arg, int count){
	int i;
	int *ptr;

	for(i = 0; i < count; i++){
		ptr = (int *) f->esp + i + 1;
		check_address((const void *) ptr);
		arg[i] = *ptr;
	}

}
